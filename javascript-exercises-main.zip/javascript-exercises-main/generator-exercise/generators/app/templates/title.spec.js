let <%= title %> = require('./<%=title%>')

describe('<%=title%>', function() {
  test('EDITME', function() {
    expect(<%=title%>()).toEqual(' ');
  });

});
