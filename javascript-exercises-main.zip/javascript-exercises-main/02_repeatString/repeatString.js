const repeatString = function() {

};

// Do not edit below this line
module.exports = repeatString;
