const helloWorld = function() {
  return ''
};

module.exports = helloWorld;
